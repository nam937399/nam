<!-- 
    $username="root";
    $password="";
    $localhost="localhost";
    $dbname="dangkinguoidung";

    $conn= new mysqli($localhost,$username,$password,$dbname);
    if($conn->connect_error)
    {
        die ("ket noi khong thanh cong :".$conn->connect_error);}
    // }else{
    //         echo("ket noi thanh cong");
    // }        
 -->
<?php
$mysqli = new mysqli("localhost","root","","test");

// Check connection
if ($mysqli -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}

?>