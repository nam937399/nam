<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="sanpham.css">
</head>
<body>
<div class="khungdau">
        <div class="logo">
            <div class="anhlogo">
                <img src="image/logowed.png">
            </div>
            <div class="search">
             <input type="" placeholder="Nhập nội dung tìm kiếm">
             <button class="Button" tabindex="0" type="button" aria-label="Button">
                <i class="fa fa-search " aria-hidden="true"></i>
            </button>
            <div class="phannhapky">
                <div class="dangnhap">
                <div class="Fontsz">
                    <a href="index.php">Đăng Nhập</a>
                </div>
                    <div class="dangky">
                   <!-- <form action="index.php"> -->
                        <div class="Fontszz">
                            <a href="login.php">Đăng Kí</a>
                        </div>
                    </div>
                    <div class="hang">
                    <a href="form.php">Giỏ Hàng</a>
                </div>
                </div>
            </div>
        </div>
        
        <div class="phanmenu">
            <div class="Menu">
                <ul class="menu1">
                    <li class="sanpham">
                        <a href="">San Phẩm</a>
                    </li>
                    <li class="sanpham">
                        <a href="">Hàng Mới Về</a>
                    </li>
                    <li class="sanpham">
                        <a href="">Thương Hiệu </a>
                    </li>
                    <li class="sanpham">
                        <a href="">Về Milem</a>
                    </li>
                    <li class="sanpham">
                        <a href="">Cửa Hàng</a>
                    </li>
                    <li class="sanpham">
                        <a href="">The Spa</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="khunggiua">
            <div class="boder">
                <div class="sanphamduoi">
                    <h2>Trang Chủ/ Sản Phẩm</h2>
                </div>
                <div class="bannerduoi">
                    <div class="anhtrai">
                         <img src="image/sanphambanner.webp" alt="">
                        </div> 
                        <div class="anhphai">
                            <div class="sanphambanner">
                                <h2> Sản Phẩm</h2><br>
                                <h3>Tại MILEM bạn sẽ được:</h3><br>
                                <h4>Chia sẻ kiến thức chăm sóc da theo từng độ tuổi.</h4>
                                <h4>Tư vấn quy trình dưỡng da phù hợp theo nhu cầu.</h4>
                                <h4>Cam kết hàng chính hãng đã qua kiểm nghiệm và chọn lọc.</h4>
                            </div>
                        </div>
                     </div>
                </div>
                <div class="duoianh">

                </div>
            </div>
            <div class="sanphamchinh">
                <div class="cacloaisp">
                    <div class="bodderml">
                        <h2>Các Loại Sản Phẩm</h2>
                    </div>
                    <div class="mucluc">
                        <div class="mltrai">
                            <div class="bondermltrai">
                                <div class="sp">
                                    <h2>SẢn Phẩm</h2>
                                </div>
                                <div class="th">
                                    <h2>Thương Hiệu</h2>
                                </div>
                                <div class="gia">
                                     <h2>Giá</h2>
                                </div>
                                </div>
                        </div>
                        <div class="mlphai">
                            <div class="khungsanpham">
                                <div class="khung1">
                                    <div class="khung2">
                                        <img src="image/sanpham1.webp" alt="">
                                         <div class="chu">
                                        <h2>FANCL Mild Cleansing Oil - Dầu tẩy trang</h2><br>
                                        <div class="chuduoi1">
                                        <h2>600.000đ</h2>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="khung3">
                                        <img src="image/sanpham2.webp" alt="">
                                    
                                    <div class="chu">
                                        <h2>FLA MER The Treatment Lotion Hydrating Mask - Mặt nạ tái tạo da</h2><br>
                                        <div class="chuduoi1">
                                        <h2>620.000đ</h2>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="khung4">
                                        <img src="image/sanpham3.webp" alt="">
                                        <div class="chu">
                                        <h2>SK-II Facial Treatment Essence White Rabbit - Nước thần con thỏ</h2><br>
                                        <div class="chuduoi1">
                                        <h2>4.200.000đ</h2>
                                        </div>
                                    </div>
                                </div>
                                </div>
                                
                                <div class="khung5">
                                    <div class="khung6">
                                        <img src="image/sanpham4.png" alt="">
                                    <div class="chu">
                                        <h2>KERASTASE Specifique Bain Prevention - Dầu gội trị rụng tóc dành cho da đầu nhạy cảm</h2><br>
                                        <div class="chuduoi1">
                                        <h2>990.000đ</h2>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="khung7">
                                        <img src="image/sanpham5.png" alt="">
                                    
                                    <div class="chu">
                                        <h2>HUXLEY Cleansing Water; Be Clean, Be Moist - Nước tẩy trang</h2> <br>
                                        <div class="chuduoi1">
                                        <h2>550.000đ</h2>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="khung8">
                                        <img src="image/sanpham6.png" alt="">
                                        <div class="chu">
                                        <h2>GLUTANEX Melanin Blocking Sun Stick SPF50 PA++++ - Sáp lăn chống nắng sáng da</h2><br>
                                        <div class="chuduoi1">
                                        <h2>1.050.000đ</h2>
                                        </div>
                                    </div>
                                </div>
                                </div>
                        

                                <div class="khung9">
                                    <div class="khung10">
                                        <img src="image/sanpham7.png" alt="">
                                    <div class="chu">
                                        <h2>BIODERMA Solution Micellaire Demaquillante - Nước tẩy trang (Da nhạy cảm) 500ml/h2><br>
                                        <div class="chuduoi1">
                                        <h2>515.000đ</h2>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="khung11">
                                        <img src="image/sanpham8.png" alt="">
                                    
                                    <div class="chu">
                                        <h2>VALMONT Priming with A Hydrating Fluid - Xịt khoáng cấp ẩm căng bóng da</h2><br>
                                        <div class="chuduoi1">
                                        <h2>Liên Hệ Cửa Hàng</h2>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="khung12">
                                        <img src="image/sanpham9.png" alt="">
                                        <div class="chu">
                                        <h2>BIODERMA Solution Micellaire Nettoyante Purifiante - Nước tẩy trang (Da dầu/mụn) 500ml</h2><br>
                                        <div class="chuduoi1">
                                        <h2>500.000đ</h2>
                                        </div>
                                    </div>
                                </div>
                                </div>

                                <div class="khung13">
                                    <div class="khung14">
                                        <img src="image/sanpham10.png" alt="">
                                    <div class="chu">
                                        <h2>VALMONT V-Firm Eye - Gel dưỡng làm săn chắc & nâng mí mắt</h2><br>
                                        <div class="chuduoi1">
                                        <h2>600.000đ</h2>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="khung15">
                                        <img src="image/sanpham12.png" alt="">
                                    
                                    <div class="chu">
                                        <h2>SK-II Facial Treatment Essence Glow Up - Nước thần màu xanh</h2><br>
                                        <div class="chuduoi1">
                                        <h2>4.200.000đ</h2>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="khung16">
                                        <img src="image/sanpham11.png" alt="">
                                        <div class="chu">
                                        <h2>VALMONT V-Firm Cream - Kem dưỡng làm đầy & săn chắc da</h2><br>
                                        <div class="chuduoi1">
                                        <h2>Liên Hệ Cửa Hàng</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="khung17">
                                    <div class="khung18">
                                        <img src="image/sanpham13.png" alt="">
                                    <div class="chu">
                                        <h2>VALMONT V-Firm Serum - Tinh chất làm săn chắc & căng mọng da</h2><br>
                                        <div class="chuduoi1">
                                        <h2>600.000đ</h2>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="khung19">
                                        <img src="image/sanpham14.png" alt="">
                                    
                                    <div class="chu">
                                        <h2>SK-II Skin Signature 3D Redefining Mask - Mặt nạ nâng cơ, xoá nhăn</h2><br>
                                        <div class="chuduoi1">
                                        <h2>620.000đ</h2>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="khung20">
                                        <img src="image/sanpham18.png" alt="">
                                        <div class="chu">
                                        <h2>HUXLEY Scrub Mask; Sweet Therapy - Tẩy da chết</h2><br>
                                        <div class="chuduoi1">
                                        <h2>580.000đ</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="khung21">
                                    <div class="khung22">
                                        <img src="image/sanpham15.png" alt="">
                                    <div class="chu">
                                        <h2>SK-II Pitera Is All I Need - Bộ 4 sản phẩm chống lão hoá căng bóng</h2><br>
                                        <div class="chuduoi1">
                                        <h2>2.700.000đ</h2>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="khung23">
                                        <img src="image/sanpham16.png" alt="">
                                    
                                    <div class="chu">
                                        <h2>SK-II Facial Treatment Gentle Cleanser - Sữa rửa mặt</h2><br>
                                        <div class="chuduoi1">
                                        <h2>1.700.000đ</h2>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="khung24">
                                        <img src="image/sanpham17.png" alt="">
                                        <div class="chu">
                                        <h2>HUXLEY Cleansing Gel; Be Clean, Be Moist - Gel rửa mặt</h2><br>
                                        <div class="chuduoi1">
                                        <h2>550.000đ</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="cuoi">
        <div class="khungcuoi">
            <div class="p1">
                <p>461 Tô Hiến Thành, P.14, Q.10, HCM<br>
                    Email: info@milem.vn<br>
                    Hotline: 0932 981 560<br>
                    Giờ làm việc<br>
                    Thứ 2 - Thứ 7: 10:00 - 21:30<br>
                    Chủ Nhật: 12:30 - 21:30</p>
            </div>
            <div class="p2">
                <p>Menu<br><br>
                    Sản phẩm<br>
                    Hàng mới về<br>
                    Thương hiệu<br>
                    Về Milem<br>
                    Cửa hàng<br>
                    The Spa</p>
            </div>
            <div class="p3">
                <p>Thông tin và hướng dẫn<br><br>
                    Hình thức thanh toán<br>
                    Chính sách bảo mật<br>
                    Điều khoản sử dụng<br>
            </div>
    </div>
    </div>    
</body>
</html>
