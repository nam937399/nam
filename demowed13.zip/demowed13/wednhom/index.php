<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Document</title>
</head>
<body>
    <div class="login" >

        <form action="nhan1.php" methond="post">
            <div class="login1">
                <br>
            <H2>Đăng Nhập Tài Khoản</H2>
            <br>
        </div>
        
            <br>
            <div class="tendangnhap">
                <p>Tên Đăng Nhập</p>
                <br>
                <input type="text" placeholder="Enter Username" name ="username" id="tennguoidung">
                <br>
                <br>
            </div>
      
            <div class="matkhau">
                <p>Mật Khẩu</p>
                <br>
                <input type="Password" placeholder="Enter Password" name="password" id="passwork">
                <br>
                <br>
            </div>
              <br>
            <div class="check">
                <input type="checkbox">Remerber me </input>
            </div> 
            <br>
                <button type="submit" name ="dangnhap" value="Đăng Nhập" onclick="removeday('Đăng nhập thành công') "class="nut">Đăng Nhập</button>
            <br>
            <br>
                <button type="submit" name ="dangki" value="Đăng Kí" class="nut">
                            <a href="login.php">Đăng Kí</a>
                            
                <br>

        </form>
    </div>
</body>
</html>