 <?php
  
   $mysqli = new mysqli("localhost","root","","dangkinguoidung");
   
   // Check connection
   if ($mysqli -> connect_errno) {
     echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
     exit();
   }
  
    $tennguoidung = $_POST['tennguoidung'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $diachi = $_POST['diachi'];
    $gender = $_POST['gender'];
    
    //$sql="INSERT INTO user (tennguoidung,username,password,email,diachi,gender) VALUES ('Cardinal', 'Tom B. Erichsen', '123', 'Stavanger@gmail', '4006', 'nam')";
    $sql = "INSERT INTO user(tennguoidung,username,`password`,email,diachi,gender) VAlUES('$tennguoidung','$username','$password','$email','$diachi','$gender')";

    $kq= mysqli_query($mysqli,$sql);
    if ($kq) {
        require_once "wedmypham.php";
    }
    else{
        echo "loi";
    }
      
    $mysqli -> close();
   
    


    // if(insset($_POST[ 'dangki'])){

    // }

    // $username = $_POST['username'];
    // $password = $_POST['password'];
    // $sql = "SELECT * FROM user WHERE username='$username' and passwork='$password'";

    // $kq = mysqli_query($conn,$sql);
    // if(mysqli_num_rows($kq)>0)
    // {
        
    // }
    // else
    // {
    //     echo"sai tk hoac mk";
    // }
    

?>
