<?php
     require 'connect.php';
    if(isset($_POST['btnthem'])){
        echo"<pre>";
    print_r($_POST);
    $masp=$_POST["masp"];
    $tensp=$_POST["tensp"];
    $soluong=$_POST["soluong"];
    $gia=$_POST["gia"];
    // echo"<pre>";
    // print_r($_POST);
        // if(!empty($masp)&&(!empty($tensp)&&(!empty($soluongp)&&(!empty($gia)&&(!empty($ngaylap)){
    $sql = "INSERT INTO `tbl_hang` (`masp`,`tensp`,`soluong`,`gia`) VALUES ('$masp','$tensp','$soluong','$gia')";
            
    if($conn->query($sql)===TRUE){
            echo"Luu du lieu thanh cong";
        }else{
            echo "Loi {$sql}".$conn->error;
        }
    } 
?>