<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="form.css">
    <title>Document</title>
</head>
<body>
    <div class="khungdau">
        <div class="logo">
            <div class="anhlogo">
                <img src="images/logowed.png">
            </div>
            <div class="search">
             <input type="" placeholder="Nhập nội dung tìm kiếm">
             <button class="Button" tabindex="0" type="button" aria-label="Button">
                <i class="fa fa-search " aria-hidden="true"></i>
            </button>
            <div class="phannhapky">
                <div class="dangnhap">
                <div class="Fontsz">
                    <a href="">Giỏ Hàng</a>
            </div>
    </div>
        </div>
        </div>
        </div>
        </div>
        <div class="login">
            <form action="xuly.php" method="Post">
                <H2>THÊM HÀNG</h2>
            Mã sản phẩm  <br>
            <br><input type="text" name="masp" required><br>
            Tên sản phẩm <br> <br> <input type="text" name="tensp" required> <br>
            Số lượng   <br><br><input type="number" name="soluong" required> <br>
            Giá   <br><br><input type="number" name="gia" required> <br>
            <!-- Ngày lập <input type="date" name="ngaylap" required> <br> -->
            <br><input type="submit" value="Thêm" name="btnthem">
            <br>
            <input type="reset" value ="Trở Về">
            <a href="wedmypham.php"></a>
            </form>
        </div>
    </div>
</body>
</html>