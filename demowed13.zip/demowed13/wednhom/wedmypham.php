<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="wedmypham.css">
    <title>wed my pham</title>
</head>
<body>
    <div class="khungdau">
        <div class="logo">
            <div class="anhlogo">
                <img src="image/logowed.png">
            </div>
            <div class="search">
             <input type="" placeholder="Nhập nội dung tìm kiếm">
             <button class="Button" tabindex="0" type="button" aria-label="Button">
                <i class="fa fa-search " aria-hidden="true"></i>
            </button>
            <div class="phannhapky">
                <div class="dangnhap">
                <div class="Fontsz">
                    <a href="index.php">Đăng Nhập</a>
                </div>
                
                    <div class="dangky">
                   <!-- <form action="index.php"> -->
                        <div class="Fontszz">
                            <a href="login.php">Đăng Kí</a>
                        </div>
                    </div>
                    <div class="hang">
                    <a href="form.php">Giỏ Hàng</a>
                </div>
                </div>
            </div>
        </div>
        
        <div class="phanmenu">
            <div class="Menu">
                <ul class="menu1">
                    <li class="sanpham">
                        <a href="sp.php">San Phẩm</a>
                    </li>
                    <li class="sanpham">
                        <a href="">Hàng Mới Về</a>
                    </li>
                    <li class="sanpham">
                        <a href="">Thương Hiệu </a>
                    </li>
                    <li class="sanpham">
                        <a href="">Về Milem</a>
                    </li>
                    <li class="sanpham">
                        <a href="">Cửa Hàng</a>
                    </li>
                    <li class="sanpham">
                        <a href="">The Spa</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="khunggiua">
            <div class="banner">
                <img src="image/banner.png.webp" alt="">
            </div>
            <div class="sanpham">
                <h2>SẢN PHẨM MỚI</h2>
            </div>
            <div class="anhsp">
                <div class="thongtin">
                    <img src="image/anh2_1.png">
                    <p>SK-II Facial Treatment Essence White Rabbit - Nước thần con thỏ</p><br>
                    <div class="thongtin_gia">
                        <p>4.200.000</p>
                    </div>
                </div>
                <div class="thongtin1">
                    <img src="image/anh2.png">
                    <p>GLUTANEX Glow Vita Mask - Mặt nạ dưỡng ẩm, dưỡng sáng & căng bóng</p><br>
                    <div class="thongtin_gia1">
                        <p>200.000</p>
                    </div>
                </div>
                <div class="thongtin2">
                    <img src="image/anh3.png">
                    <p>MD DERMATICS Maxfirm Firming Eye Cream - Kem mắt điều trị bọng mắt</p><br>
                    <div class="thongtin_gia2">
                        <p>2.400.000</p>
                    </div>
                </div>
                <div class="thongtin3">
                    <img src="image/anh4.png">
                    <p>MD DERMATICS Revita Plus Brightening Serum - Huyết thanh làm sáng & dưỡng ẩm</p><br>
                    <div class="thongtin_gia3">
                        <p>2.800.000</p>
                    </div>
                </div>
            </div>
            <div class="anhbu">
               <img src="image/banner.png" alt="">
               <img src="image/banner2.png" alt="">
           </div>
           <div class="spgy">
            <h2>SẢN PHẨM GỢI Ý</h2>
        </div>
        <div class="anhsp">
            <div class="thongtin">
                <img src="image/anh5.png">
                <p>SKINSHOT Bioactive Collagen Shot - Nước uống Collagen đẹp da trị nám</p><br>
                <div class="thongtin_gia">
                    <p>2.900.000</p>
                </div>
            </div>
            <div class="thongtin1">
                <img src="image/anh6.png">
                <p>IS CLINICAL Hydra-Cool Serum - Tinh chất cấp nước, dưỡng ẩm & làm dịu da</p><br>
                <div class="thongtin_gia1">
                    <p>3.200.000</p>
                </div>
            </div>
            <div class="thongtin2">
                <img src="image/anh7.png">
                <p>VALMONT Face Exfoliant - Kem tẩy tế bào chết tái sinh làn da</p><br><br>
                <div class="thongtin_gia2">
                    <p>Liên hệ</p>
                </div>
            </div>
            <div class="thongtin3">
                <img src="image/anh8.png">
                <p>VALMONT Votre Visage - Kem dưỡng chống lão hoá tối ưu</p><br><br>
                <div class="thongtin_gia3">
                    <p>4.800.000</p>
                </div>
            </div>
        </div>
        <div class="thuonghieu">
            <h2>Thương Hiệu</h2>
        </div>
        <div class="anhsp">
            <div class="thuonghieu1">
                <img src="image/thuonghieu1.png">
            </div>
            <div class="thuonghieu2">
                <img src="image/thuonghieu2.png">             
            </div>
            <div class="thuonghieu3">
                <img src="image/thuonghieu3.png">
            </div>
            <div class="thuonghieu4">
                <img src="image/thuonghieu4.png">
            </div>
        </div>
    </div>
    </div>
    </div>
    <div class="cuoi">
        <div class="khungcuoi">
            <div class="p1">
                <p>461 Tô Hiến Thành, P.14, Q.10, HCM<br>
                    Email: info@milem.vn<br>
                    Hotline: 0932 981 560<br>
                    Giờ làm việc<br>
                    Thứ 2 - Thứ 7: 10:00 - 21:30<br>
                    Chủ Nhật: 12:30 - 21:30</p>
            </div>
            <div class="p2">
                <p>Menu<br><br>
                    Sản phẩm<br>
                    Hàng mới về<br>
                    Thương hiệu<br>
                    Về Milem<br>
                    Cửa hàng<br>
                    The Spa</p>
            </div>
            <div class="p3">
                <p>Thông tin và hướng dẫn<br><br>
                    Hình thức thanh toán<br>
                    Chính sách bảo mật<br>
                    Điều khoản sử dụng<br>
            </div>
    </div>
</body>
</html> 