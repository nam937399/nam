<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="form.css">
    <title>Document</title>
</head>
<body>
    <div class="khungdau">
        <div class="logo">
            <div class="anhlogo">
                <img src="image/logowed.png">
            </div>
            <div class="search">
             <input type="" placeholder="Nhập nội dung tìm kiếm">
             <button class="Button" tabindex="0" type="button" aria-label="Button">
                <i class="fa fa-search " aria-hidden="true"></i>
            </button>
            <!-- <div class="phannhapky">
                <div class="dangnhap">
                <div class="Fontsz">
                    <a href="">Giỏ Hàng</a> -->

    </div>
        </div>
        </div>
        </div>
        </div>
        <div class="phanmenu">
            <div class="Menu">
                <ul class="menu1">
                    <li class="sanpham">
                        <a href="">San Phẩm</a>
                    </li>
                    <li class="sanpham">
                        <a href="">Hàng Mới Về</a>
                    </li>
                    <li class="sanpham">
                        <a href="">Thương Hiệu </a>
                    </li>
                    <li class="sanpham">
                        <a href="">Về Milem</a>
                    </li>
                    <li class="sanpham">
                        <a href="">Cửa Hàng</a>
                    </li>
                    <li class="sanpham">
                        <a href="">The Spa</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="login">
        <div class="anhphu">
                <img src="image/anhdangnhap.png" alt="">
                <img src="image/anhdangnhap1.jpeg" alt="">
                </div>
                
      
            <form action="xuly.php" method="Post">
                <H2>THÊM HÀNG</h2>
                <br>
            Mã sản phẩm  <br>   
            <br><input type="text" name="masp" required><br>    <br>
            Tên sản phẩm <br> <br> <input type="text" name="tensp" required> <br>    <br>
            Số lượng   <br><br><input type="number" name="soluong" required> <br><br>
            Giá   <br><br><input type="number" name="gia" required> <br>
            <!-- Ngày lập <input type="date" name="ngaylap" required> <br> -->
            <br><input type="submit" value="Thêm" name="btnthem">
            <a href="lietke.php">Trở Về</a>
            <br><br>    <br>
            <button type="reset" value ="Trở Về" name="btnve" class="btnve">  
                       <a href="wedmypham.php">Trở Về</a>
            </form>
        </div>
    </div>
    </div> 
</body>
</html>