<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Document</title>
</head>
<body>
    <div class="login" >
        <form action="nhan.php" method="post">
            <div class="login1">
                <br>
            <H2>Đăng Kí Tài Khoản</H2>
            </div>
        
            <br>
            <div class="Hvt">
                <p>Họ và Tên</p>
                <br>
                <input type="text" placeholder="Họ và Tên" name ="tennguoidung" required>
                <br>
                <br>
            </div>
            <div class="tendangnhap">
                <p>Tên Đăng Nhập</p>
                <br>
                <input type="text" placeholder="Enter Username" name ="username"required >
                <br>
                <br>
            </div>
      
            <div class="matkhau">
                <p>Mật Khẩu</p>
                <br>
                <input type="Password" placeholder="Enter Password" name="password" required>
                <br>
                <br>
            </div>
            <div class="gmail">
                 <p>Email</p>
                <br>
                <input type="email" placeholder="Email" name="email" required>
                <br>
                <br>
            </div>
                <div class="gioittinh">
                <p>Giới Tính</p>
                <br>
                    <input type="radio" name="gender" check id="male" value="nam">
                    <lable>Nam</lable>
                    <input type="radio" name="gender" check id="female" value="nu">
                    <lable>Nữ</lable>
              </div>
              <br>
              <div class="diachi">
                 <p>Địa Chỉ</p>
                <br>
                <input type="text" placeholder="Nhập địa chỉ của bạn" name="diachi"required >
                <br>
                <br>
            </div>
            <!-- <div class="check">
                <input type="checkbox">Remerber me </input>
            </div> -->
            <br>
                <button type="submit" name ="dangki" value="Đăng kí" class="nut">Đăng Kí</button>
            <br>
        </form>
    </div>
</body>
</html>