    <?php
        require_once 'connect.php';
        //cau lenh
        $lietke_sql = "SELECT * FROM Khachhang order by gmail, Passwword";
        
        $result = mysqli_query($conn,$lietke_sql);
        while ($r = mysqli_fetch_assoc($result)){
            echo $r['id'] . " - "  .$r ['gamil'] . " - ".$r['Password']; 
        }

    ?>