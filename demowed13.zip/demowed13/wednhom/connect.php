<?php
$mysqli = new mysqli("localhost","root","","test");
// $conn = mysqli_connect("localhost","root","","test");

// Check connection
if ($mysqli -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}

?>