<?php
     require 'connect.php';
    if(isset($_POST['btnthem'])){
        echo"<pre>";
    print_r($_POST);
    $masp=$_POST["masp"];
    $tensp=$_POST["tensp"];
    $soluong=$_POST["soluong"];
    $gia=$_POST["gia"];
    // echo"<pre>";
    // print_r($_POST);
        // if(!empty($masp)&&(!empty($tensp)&&(!empty($soluongp)&&(!empty($gia)&&(!empty($ngaylap)){
    $sql = "INSERT INTO hang(masp,tensp,soluong,gia) VALUES ('$masp','$tensp','$soluong','$gia')";
            print_r($sql);
            // if(mysqli_query($conn,$sql)){  
            //     echo"Luu du lieu thanh cong";
            // }
    if($conn ->query($sql)===TRUE){
            print_r($sql);
            echo"Luu du lieu thanh cong";

        }else{
            echo "Loi {$sql}".$conn->error;
        }
    } include("wedmypham.php");
?>
