<?php
    require 'connect.php';
    // if(insset($_POST[ 'dangki'])){

    // }

    // $username = $_POST['username'];
    // $password = $_POST['password'];
    // $sql = "SELECT * FROM user WHERE username='$username' and passwork='$password'";

    // $kq = mysqli_query($conn,$sql);
    // if(mysqli_num_rows($kq)>0)
    // {
        
    // }
    // else
    // {
    //     echo"sai tk hoac mk";
    // }
    include("wedmypham.php");
    // echo "<pre>";
    // print_r($_POST);
?>